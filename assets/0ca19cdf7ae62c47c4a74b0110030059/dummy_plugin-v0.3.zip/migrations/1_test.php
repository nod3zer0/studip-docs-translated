<?
class Test extends DBMigration {
    function up () {
        $this->db->query("INSERT INTO dummy VALUES (42, 'axel')");
    }

    function down () {
        $this->db->query("DELETE FROM dummy WHERE id = 42");
    }
}
?>
