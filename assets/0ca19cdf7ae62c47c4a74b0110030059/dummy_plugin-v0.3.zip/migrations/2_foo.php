<?
class Foo extends DBMigration {
    function up () {
        $this->db->query("INSERT INTO dummy VALUES (7, 'elmar')");
    }

    function down () {
        $this->db->query("DELETE FROM dummy WHERE id = 7");
    }
}
?>
