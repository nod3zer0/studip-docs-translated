-- 
-- Tabelle `dummy`
-- 

DROP TABLE `dummy`;
