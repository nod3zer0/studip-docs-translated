-- 
-- Tabellenstruktur f�r Tabelle `dummy`
-- 

CREATE TABLE IF NOT EXISTS `dummy` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `user` varchar(32) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;
